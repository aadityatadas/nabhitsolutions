<?php
	//session_start();
	include('dbinfo.php');
	if(!empty($_POST))  
	{	
		$cid = mysqli_real_escape_string($connect, $_POST["sentiid"]);
		if($_FILES["rpt_rpt3"]["name"] != '')
		{
			function upload_rpt3()
			{
				if(isset($_FILES["rpt_rpt3"]))
				{
					$extension = explode('.', $_FILES['rpt_rpt3']['name']);
					$new_nameon = rand() . '.' . $extension[1];
					$destination = './upload_eqp/' . $new_nameon;
					move_uploaded_file($_FILES['rpt_rpt3']['tmp_name'], $destination);
					return $new_nameon;
				}
			}
			if($_FILES["rpt_rpt3"]["name"] != '')
			{
				$imageth = upload_rpt3();
			}
			$sql1 = "UPDATE tbl_eqp_mast_bio SET eqp_csch_img = '$imageth' WHERE eqpid = '$cid'";  
			mysqli_query($connect, $sql1);				
		}
	}
	else{
		echo "Oops There is Some Problem, Please check?";  
	} 
?>