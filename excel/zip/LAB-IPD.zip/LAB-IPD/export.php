<?php  
//export.php  
include("../config/config.php");
$output = '';
if(isset($_POST["export"]))
{
$query = "SELECT tbl_huf.* , tbl_lab_ipd.* FROM tbl_huf LEFT JOIN tbl_lab_ipd ON tbl_huf.huf_id = tbl_lab_ipd.tbl_uhf_id ";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                    <th width="35%">Sr. No.</th>
                    <th width="20%">Name of the Patient</th>
                    <th width="25%">UHID No</th>
                    <th width="20%">IPD No</th>
                    <th width="20%">Date of Admission</th>
                    <th width="20%">Provisional/Final Diagnosis</th>
                    <th width="20%">Name of Test </th>
                    <th width="20%">Sample Receiving Date-Time</th>
                    <th width="20%">Date-Time of Report Generation</th>
                    <th width="20%">Total Time</th>
                    <th width="20%">Investigation Result</th>
                    <th width="20%">Critical Result If Any</th>
                    <th width="20%">Critical Alert Details</th> 
                    <th width="20%">Result Time </th>
                    <th width="20%">Informed Time</th>
                    <th width="20%">Informed To</th>
                    <th width="20%">Infromed By</th>
                    <th width="20%">Reporting Error If Any</th>
                    <th width="20%">Reason For Reporting Error</th>
                    <th width="20%"> Redos If Any</th>
                    <th width="20%">Reason For Redos</th>
                    <th width="20%">Reports-Corelating With Clinical Diagnosis </th>
                    <th width="20%">Clinical Correlation</th>
                    <th width="20%">Remarks</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
        <tr>  
        <td>'.$row["huf_id"].'</td>  
        <td>'.$row["huf_pname"].'</td>  
        <td>'.$row["huf_uhid"].'</td>  
        <td>'.$row["huf_ipd"].'</td>  
        <td>'.$row["huf_dadm"].'</td>
        <td>'.$row["prov_finl_daig"].'</td>  
        <td>'.$row["nam_of_test"].'</td>
        <td>'.$row["sample_rec_time_date"].'</td>  
        <td>'.$row["time_date_of_rep_gen"].'</td>  
        <td>'.$row["total_time"].'</td>
        <td>'.$row["inv_result"].'</td>
        <td>'.$row["cri_res_if_any"].'</td>
        <td>'.$row["cri_alrt_details"].'</td>
        <td>'.$row["result_time"].'</td>
        <td>'.$row["info_time"].'</td>
        <td>'.$row["info_to"].'</td>
        <td>'.$row["info_by"].'</td>
        <td>'.$row["resp_err"].'</td>
        <td>'.$row["res_err_rsn"].'</td>
        <td>'.$row["redos"].'</td>
        <td>'.$row["redos_rsn"].'</td>
        <td>'.$row["rep_cor_clin_diag"].'</td>
        <td>'.$row["clinical_correlation"].'</td>
        <td>'.$row["remarks"].'</td>
        </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
