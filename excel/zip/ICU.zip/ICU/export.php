<?php  
//export.php  
include("../config/config.php");
$output = '';
if(isset($_POST["export"]))
{
$query = "SELECT tbl_huf.* , tbl_icu_register_ipd.* FROM tbl_huf LEFT JOIN tbl_icu_register_ipd ON tbl_huf.huf_id = tbl_icu_register_ipd.tbl_huf_id ";

 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                    <th width="35%">Sr. No.</th>
                    <th width="20%">Name of the Patient</th>
                    <th width="25%">UHID No</th>
                    <th width="20%">IPD No</th>
                    <th width="20%">Date Of Admission In ICU</th>
                    <th width="20%">Time Of Admission In ICU</th>
                    <th width="20%">Date of Discharge/Transfer In ICU </th>
                    <th width="20%"> Time of Discharge/Transfer In ICU</th>
                    <th width="20%">Date of Return TO ICU</th>
                    <th width="20%">Time of Return TO ICU</th>
                    <th width="20%">Return To ICU WithIn 48 Hrs</th>
                    <th width="20%">ReAdmission</th>
                    <th width="20%">ReIntubation</th> 
                    <th width="20%">Sign</th>
                     
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
        <td>'.$row["huf_id"].'</td>  
        <td>'.$row["huf_pname"].'</td>  
        <td>'.$row["huf_uhid"].'</td>  
        <td>'.$row["huf_ipd"].'</td>  
        <td>'.$row["date_of_admison_in_icu"].'</td>
        <td>'.$row["time_of_admison_in_icu"].'</td>  
        <td>'.$row["date_of_disc_trans_in_icu"].'</td>
        <td>'.$row["time_of_disc_trans_in_icu"].'</td>  
        <td>'.$row["date_of_return_in_icu"].'</td>  
        <td>'.$row["time_of_return_in_icu"].'</td>
        <td>'.$row["retrn_to_icu_in_48hrs"].'</td>
        <td>'.$row["re_admission"].'</td>
        <td>'.$row["re_intubation"].'</td>
        <td>'.$row["sign"].'</td>
         

        </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
