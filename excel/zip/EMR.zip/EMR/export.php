<?php  
//export.php  
include("../config/config.php");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT tbl_huf.* , tbl_emrgncy_register_ipd.* FROM tbl_huf LEFT JOIN tbl_emrgncy_register_ipd ON tbl_huf.huf_id = tbl_emrgncy_register_ipd.tbl_huf_id ";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                    <th width="35%">Sr. No.</th>
                    <th width="20%">Name of the Patient</th>
                    <th width="25%">UHID No</th>
                    <th width="20%">IPD No</th>
                    <th width="20%">Date Of Patient Arrival At The Emergency</th>
                    <th width="20%">Time Of Patient Arrival At The Emergency </th>
                    <th width="20%">Time Of Initial Assessment Is Completed By Doctor </th>
                    <th width="20%">Time Taken For Initial Assessment</th>
                    <th width="20%">Patient Complaint</th>
                    <th width="20%">Mlc </th>
                    <th width="20%">Brought Dead</th>
                    <th width="20%">Date Of Return To Emergency Department If Any</th>
                    <th width="20%">Time Of Return To Emergency Department If Any</th> 
                    <th width="20%">Patient Complaint  On Return To Emergency </th>
                    <th width="20%">Return To The Emergency Department With In 72 Hours With Similar Presenting Complaint If Any</th>
                    <th width="20%">Sign </th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
        <td>'.$row["huf_id"].'</td>  
        <td>'.$row["huf_pname"].'</td>  
        <td>'.$row["huf_uhid"].'</td>  
        <td>'.$row["huf_ipd"].'</td>  
        <td>'.$row["date_of_patient_arrvl_at_emrgncy"].'</td>
        <td>'.$row["time_of_patient_arrvl_at_emrgncy"].'</td>  
        <td>'.$row["time_of_intl_ass_is_cmpltd_by_doc"].'</td>
        <td>'.$row["time_taken_for_initl_assmnt"].'</td>  
        <td>'.$row["patient_cmplnt"].'</td>  
        <td>'.$row["m_l_c"].'</td>
        <td>'.$row["brought_dead"].'</td>
        <td>'.$row["date_of_retrn_to_emrgncy_dept_if_any"].'</td>
        <td>'.$row["time_of_retrn_to_emrgncy_dept_if_any"].'</td>
        <td>'.$row["patients_comp_on_rtn_of_emrgncy"].'</td>
        <td>'.$row["retn_of_emrgncy"].'</td>
        <td>'.$row["sign"].'</td>

        </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
