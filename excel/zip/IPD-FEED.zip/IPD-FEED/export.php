<?php  
//export.php  
include("../config/config.php");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM tbl_ipd";
  $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                   <tr>  
                    <th width="35%">Sr No</th>
                        <th width="20%">Date</th>
                        <th width="20%">Name(Optional)</th>
                        <th width="20%">Age</th>
                        <th width="20%">Sex</th>
                        <th width="20%">Email</th>
                        <th width="20%">Address</th>
                        <th width="20%">Treating Doctor</th>
                        <th width="20%">Heard about hospital from</th>
                        <th width="20%">Heard about hospital from</th>
                        <th width="20%">Heard about hospital from</th>
                        <th width="20%">Other</th>
                        <th width="20%">Score (Out of 120)</th>
                        <th width="20%">Recorded By</th>
                        
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["ipd_id"].'</td>  
                         <td>'.$row["ipdid"].'</td>  
                         <td>'.$row["ipd_age"].'</td>  
                         <td>'.$row["ipd_sex"].'</td> 
                         <td>'.$row["ipd_email"].'</td> 
                         <td>'.$row["ipd_addr"].'</td>
                         <td>'.$row["ipd_trdr"].'</td>
                         <td>'.$row["ipd_hrd1"].'</td>
                         <td>'.$row["ipd_hrd2"].'</td>
                         <td>'.$row["ipd_hrd3"].'</td>
                         <td>'.$row["ipd_oth"].'</td>
                         <td>'.$row["ipd_chk1"].'</td>
                         <td>'.$row["ipd_chk2"].'</td>
                         <td>'.$row["ipd_chk3"].'</td>
                         <td>'.$row["ipd_chk4"].'</td>
                         <td>'.$row["ipd_chk5"].'</td>
                         <td>'.$row["ipd_chk6"].'</td>
                         <td>'.$row["ipd_chk7"].'</td>
                         <td>'.$row["ipd_chk8"].'</td>
                         <td>'.$row["ipd_chk9"].'</td>
                         <td>'.$row["ipd_chk10"].'</td>
                         <td>'.$row["ipd_chk11"].'</td>
                         <td>'.$row["ipd_chk12"].'</td>
                         <td>'.$row["ipd_chk13"].'</td>
                         <td>'.$row["ipd_chk14"].'</td>
                         <td>'.$row["ipd_chk15"].'</td>
                         <td>'.$row["ipd_chk16"].'</td>
                         <td>'.$row["ipd_chk17"].'</td>
                         <td>'.$row["ipd_chk18"].'</td>
                         <td>'.$row["ipd_chk19"].'</td>
                         <td>'.$row["ipd_chk20"].'</td>
                         <td>'.$row["ipd_chk21"].'</td>
                         <td>'.$row["ipd_chk22"].'</td>
                         <td>'.$row["ipd_chk23"].'</td>
                         <td>'.$row["ipd_chk24"].'</td>
                         <td>'.$row["ipd_fac"].'</td>
                         <td>'.$row["ipd_sug"].'</td>
                         <td>'.$row["ipd_score"].'</td>
                         <td>'.$row["ipd_user"].'</td>
                         


                         
       
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
