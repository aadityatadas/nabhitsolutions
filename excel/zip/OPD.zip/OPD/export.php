<?php  
//export.php  
include("../config/config.php");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM tbl_opdwttm";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                    <th width="35%">Sr. No.</th>
                    <th width="20%">Name of the Patient</th>
                    <th width="25%">UHID No</th>
                    <th width="20%">OPD No</th>
                    <th width="20%">Specialty / Doctor</th>
                    <th width="20%">Date & Time of Registration  of OPD</th>
                    <th width="20%">Date & Time by which Doctor has seen the Patient</th>
                    <th width="20%">OPD waitingTime in Min.</th>
                    <th width="20%">Recorded By</th>
                    
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                        <td>'.$row["opdwttm_id"].'</td>  
                        <td>'.$row["opdwttm_pname"].'</td>  
                        <td>'.$row["opdwttm_uhid"].'</td>  
                        <td>'.$row["opdwttm_opd"].'</td>  
                        <td>'.$row["opdwttm_drsp"].'</td>
                        <td>'.$row["opdwttm_dttmr"].'</td>  
                        <td>'.$row["opdwttm_dttmds"].'</td>  
                        <td>'.$row["opdwttm_opdwttm"].'</td> 
                        <td>'.$row["opdwttm_recd"].'</td> 
       
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
