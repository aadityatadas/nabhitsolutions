<?php
error_reporting(0);
session_start();
include('dbinfo.php');
if(isset($_POST["frdate"],$_POST["todate"]))
{
	$data[] = array('Date','No of Patient Return to ICU in 48hrs','% of Patient Return to ICU in 48hrs');
	
	$rs = mysqli_query($connect, $sq);

	// main table
	$sq = "SELECT DISTINCT date_of_admison_in_icu FROM tbl_icu_register_ipd WHERE (date_of_admison_in_icu BETWEEN '".$_POST["frdate"]."' AND '".$_POST["todate"]."') AND date_of_admison_in_icu != '' ORDER BY date_of_admison_in_icu ASC";
	$rs = mysqli_query($connect, $sq);
	$date1 = array();
	while($res = mysqli_fetch_array($rs))
	{
		$date1[] = $res["date_of_admison_in_icu"];
		
	}


	
	// add on table
	$sq = "SELECT DISTINCT date_of_admison_in_icu FROM tbl_icu_ipd2 WHERE (date_of_admison_in_icu BETWEEN '".$_POST["frdate"]."' AND '".$_POST["todate"]."') AND date_of_admison_in_icu != '' ORDER BY date_of_admison_in_icu ASC";
	$rs = mysqli_query($connect, $sq);
	$date2 = array();
	while($res = mysqli_fetch_array($rs))
	{
		$date2[] = $res["date_of_admison_in_icu"];
		
	}
	//	$data = array($data);
	
	$datearray = array_unique(array_merge($date2,$date1));			
	
  	
	    
	function date_sort($a, $b) {
    	return strtotime($a) - strtotime($b);
	}
	usort($datearray, "date_sort");
	
	foreach ($datearray as $hufdt) 
	{
		
		$cdat1 = str_replace('-', '/', $hufdt);
		$admdt = date('d M y', strtotime($cdat1));

		$table1 = 'tbl_icu_register_ipd';

	$qryICU1 = mysqli_query($connect,"SELECT count(*) as total_icu FROM $table1 WHERE (date_of_admison_in_icu = '$hufdt') AND date_of_admison_in_icu !='' ")or die(mysqli_error($connect));
	$resICU1 = mysqli_fetch_assoc($qryICU1);
	$total_icu = $resICU1["total_icu"];

	$qryICU3 = mysqli_query($connect,"SELECT count(*) as total_icu_return FROM tbl_icu_register_ipd WHERE (date_of_admison_in_icu BETWEEN '$frdt' AND '$todt') AND retrn_to_icu_in_48hrs ='Yes' ")or die(mysqli_error($connect));
	$resICU3 = mysqli_fetch_assoc($qryICU3);
	$total_icu_return = $resICU3["total_icu_return"];


	





	$per1 = $total_icu!=0 ? (($total_icu_return/$total_icu)*100) :   0 ;

	$data[] = array($admdt,(int)$total_icu_return,(float)$per1);		  
		
	}
	//	$data = array($data);			
	echo json_encode($data);
}	
?>
