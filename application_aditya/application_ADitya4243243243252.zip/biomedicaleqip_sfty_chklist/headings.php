<?php

$rowHead[0]= array('List of updated bimedical equipment shall be there with Equipment Identification tag. (EIT)','list_upted_tag_yn','list_upted_tag_loc','list_upted_tag_rmrk');
$rowHead[1]= array('Critical Biomedical equipment shall be CE certified. Under maintenance of valid service agency. AMC /CMC shall be available if not under warranty.','critical_bio_equmnt_yn','critical_bio_equmnt_loc','critical_bio_equmnt_rmrk');
$rowHead[2]= array('Preventive maintenance shall be planned (PMS schedule). With proper PMS reports.','prvintv_maintce_reports_yn','prvintv_maintce_reports_loc','prvintv_maintce_reports_rmrk');
$rowHead[3]= array('Calibration shall be done as per schedule with proper calibration reports. Calibration tags shall be displayed on machine.','calibratn_reports_yn','calibratn_reports_loc','calibratn_reports_rmrk');
$rowHead[4]= array('Breakdown shall be recorded in complaint book and down time shall be recored. It shall be as minimum as possible for critical equipements.','breakdown_equpment_yn','breakdown_equpment_loc','breakdown_equpment_rmrk');
$rowHead[5]= array(' Dos and don’t shall be displayed on equipement with proper sop to use including safety precaution.','dos_dont_precution_yn','dos_dont_precution_loc','dos_dont_precution_rmrk');
$rowHead[6]= array('7. Emergency alarm system shall be available whenever necessary for immediate alertness. (Ventilator alarms/anesthetia machine alarm etc. It shall be properly checked before every use. ','emrgncy_alarm_yn','emrgncy_alarm_loc','emrgncy_alarm_rmrk');
$rowHead[7]= array('8. Internal and external quality assurance of the machine specially dignostic machines shall be carried out with proper reports.','intrnl_extrnl_repots_yn','intrnl_extrnl_repots_loc','intrnl_extrnl_repots_rmrk');
$rowHead[8]= array(' All wires and cables shall be properly insulated to avoid any shocks to patient. Machine shall be checked daily by tester before patient use.','all_wires_use_yn','all_wires_use_loc','all_wires_use_rmrk');
$rowHead[9]= array('Qualified biomedical enginner shall mainatain the equipement with daily safety checks.','qualified_biomedcl_checks_yn','qualified_biomedcl_checks_loc','qualified_biomedcl_checks_rmrk');

?>