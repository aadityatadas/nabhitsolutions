<?php
$rowHead[0]= array('BMW Dust Bins shall be available in all patient care areas with labelled Bio- safet sticker/ and covered','bmw_dus_bins_yn','bmw_dus_bins_loc','bmw_dus_bins_rmrk');

$rowHead[1]= array('Puncture Proof container shall be used to discard needles','punctr_prof_contanr_yn','punctr_prof_contanr_loc','punctr_prof_contanr_rmrk');

$rowHead[2]= array('Bllod spillage kits shall be available for any spillgage.','bllod_spillgage_yn','bllod_spillgage_loc','bllod_spillgage_rmrk');

$rowHead[3]= array('PPE shall be available and used for protection','ppe_prctn_yn','ppe_prctn_loc','ppe_prctn_rmrk');


$rowHead[4]= array('Central Biomedical area shall have weighing machine. It shall be restricted/fenced/secured with bio safety signage. Rubber hard gloves and gum boot shall be available.','central_biomtrc_avalbl_yn','central_biomtrc_avalbl_loc','central_biomtrc_avalbl_rmrk');

$rowHead[5]= array('Needle prick injury prevention and exposure safety guidelines poster shall be displayed including do not recap guidelines.','needle_prick_gudline_yn','needle_prick_gudline_loc','needle_prick_gudline_rmrk');

$rowHead[6]= array('Staff shall be trained on biosafety and universal precautions.','staff_prcution_yn','staff_prcution_loc','staff_prcution_rmrk');

$rowHead[7]= array('Staff shall be immunized for hepatitis.','staff_hepatitis_yn','staff_hepatitis_loc','staff_hepatitis_rmrk');

?>