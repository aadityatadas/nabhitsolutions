<?php

$rowHead[0]= ' Hospital shall have atlest 3 alernative sources of power. Electricity board, UPS and Generators. Back up if DG not working';
$rowHead[1]= 'All power points shall be checked for correct working.';
$rowHead[2]= 'DG shall have suffucient level of fuel for reserve use. It shall be checked daily.';
$rowHead[3]= ' All emergency machines shall be on UPS. It shall be mainatained. AMC and Mainatance documents.';
$rowHead[4]= 'DG shalll be under AMC/CMC. Regular Mainatence chart shall be diaplayed with meter readings.';
$rowHead[5]= 'Alternate lines/Separate safety lines shall be available for critical areas like OT, Cath Lab, ICU and Casualty.';

?>